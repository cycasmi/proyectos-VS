/*
Fecha casoMenuFecha();
void casoMenuOriginal(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
void casoMenuAdministrador(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
void casoMenuCategoriasAdm(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
void casoMenuLecheAdm(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
void casoMenuQuesoAdm(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
void casoMenuYogurAdm(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);

void casoMenuCliente(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
void casoMenuCategoriasCli(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
void casoMenuLecheCli(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
void casoMenuQuesoCli(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
void casoMenuYogurCli(Almacen<Lacteos*> a, Almacen<Lacteos*> b, Almacen<Lacteos*> c, char, int *, int *, int, double *, double *);
*/

/*
Fecha casoMenuFecha();
void casoMenuOriginal(char, int *, int);
void casoMenuAdministrador(char, int *, int);
void casoMenuCategoriasAdm(char, int *, int);
void casoMenuLecheAdm(char, int *, int);
void casoMenuQuesoAdm(char, int *, int);
void casoMenuYogurAdm(char, int *, int);

void casoMenuCliente(char, int *, int);
void casoMenuCategoriasCli(char, int *, int);
void casoMenuLecheCli(char, int *, int);
void casoMenuQuesoCli(char, int *, int);
void casoMenuYogurCli(char, int *, int);
*/