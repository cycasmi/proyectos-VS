#include "Monstruo.h"
#include "Hoyo.h"

int main()
{
	Monstruo asesino(5, 5, 'A');
	cout << "El monstruo asesino te hizo un da�o de: " << asesino.danio();

	Hoyo grande(5, 5, 10);
	if (grande.danio() == -1)
		cout << "El hoyo te ha roto la pierna";

	/*Monstruo *m;
	m = new Monstruo(5, 5, 'A');
	m = new Monstruo(5, 5, 'B');
	m = new Monstruo(5, 5, 'C');


	Hoyo *h;
	h = new Hoyo(8, 8, 5);
	h = new Hoyo(8, 8, 10);*/

	return 0;
}
